<?php
require_once 'modulo.php';

class FranjaHorario
{
   
}
