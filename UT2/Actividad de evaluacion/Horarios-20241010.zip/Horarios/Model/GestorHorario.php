<?php

class GestorHorario
{

}