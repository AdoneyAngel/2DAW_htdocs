<header class="navbar navbar-light bg-light" id="cabecera" style="display: none">
    <h1>Librería</h1>
    <p id="usuarioHeader"></p>
Menú:
</header>
