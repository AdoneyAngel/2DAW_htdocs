<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Procesar pedido</title>
</head>
<body>
    <p><?php echo e($message); ?></p>
    <a href="/">Volver</a>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\2DAW_htdocs\UT3\Actividad\TejeraSantana_Adoney_dsw_ut03_proyecto - copia\resources\views/Procesar_pedido.blade.php ENDPATH**/ ?>