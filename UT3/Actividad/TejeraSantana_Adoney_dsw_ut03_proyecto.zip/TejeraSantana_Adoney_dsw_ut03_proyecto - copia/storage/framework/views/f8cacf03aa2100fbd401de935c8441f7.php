<header class="navbar navbar-light bg-light" id="cabecera" style="display: none">
    <h1>Librería</h1>
    <p id="usuarioHeader"></p>
Menú:
</header>
<?php /**PATH C:\xampp\htdocs\2DAW_htdocs\UT3\Actividad\TejeraSantana_Adoney_dsw_ut03_proyecto - copia\resources\views/Cabecera.blade.php ENDPATH**/ ?>