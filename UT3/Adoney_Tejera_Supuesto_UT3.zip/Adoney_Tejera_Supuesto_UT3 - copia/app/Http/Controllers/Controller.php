<?php

namespace App\Http\Controllers;

use App\Models\Producto;

abstract class Controller
{

}
